----------------------------------------
-- File: 'ebps\game\projectiles\chaos_missile.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\game\projectiles\krak_missile.lua]])
MetaData = InheritMeta([[ebps\game\projectiles\krak_missile.lua]])

GameData["entity_blueprint_ext"]["animator"] = "Races/Chaos/Projectiles/Chaos_Krak_Missile"
GameData["projectile_ext"]["death_event_name"] = "Projectile_Fx/chaos_Missile_Impact"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
