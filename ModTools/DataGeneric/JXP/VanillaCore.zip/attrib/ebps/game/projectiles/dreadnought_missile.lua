----------------------------------------
-- File: 'ebps\game\projectiles\dreadnought_missile.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\game\projectiles\krak_missile.lua]])
MetaData = InheritMeta([[ebps\game\projectiles\krak_missile.lua]])

GameData["entity_blueprint_ext"]["animator"] = "Races/Space_Marines/Projectiles/Dreadnought_Missile"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
