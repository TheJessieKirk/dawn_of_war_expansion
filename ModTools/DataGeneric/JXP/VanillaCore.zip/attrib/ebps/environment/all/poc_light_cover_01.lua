----------------------------------------
-- File: 'ebps\environment\all\poc_light_cover_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\all\all.nil]])
MetaData = InheritMeta([[ebps\environment\all\all.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/all/poc_light_cover01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
