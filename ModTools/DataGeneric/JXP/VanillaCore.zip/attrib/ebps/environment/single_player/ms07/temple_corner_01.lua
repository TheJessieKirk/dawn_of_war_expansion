----------------------------------------
-- File: 'ebps\environment\single_player\ms07\temple_corner_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\ms07\ms07.nil]])
MetaData = InheritMeta([[ebps\environment\single_player\ms07\ms07.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/sp/m07_temple/temple_corner_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
