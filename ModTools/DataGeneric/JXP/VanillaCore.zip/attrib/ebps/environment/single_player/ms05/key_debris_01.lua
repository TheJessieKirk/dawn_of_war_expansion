----------------------------------------
-- File: 'ebps\environment\single_player\ms05\key_debris_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\single_player\ms05\ms05.nil]])
MetaData = InheritMeta([[ebps\environment\single_player\ms05\ms05.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/sp/m05_key/key_debris_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
