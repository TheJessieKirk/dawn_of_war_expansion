----------------------------------------
-- File: 'ebps\environment\urban\dressing\statue_human_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\dressing\dressing.nil]])
MetaData = InheritMeta([[ebps\environment\urban\dressing\dressing.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/dressing/statue_human_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
