----------------------------------------
-- File: 'ebps\environment\urban\government\government_broken_02.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\government\government.nil]])
MetaData = InheritMeta([[ebps\environment\urban\government\government.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/government/government_broken_02"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
