----------------------------------------
-- File: 'ebps\environment\urban\defensive_wall\defensive_wall_01_45.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\defensive_wall\defensive_wall.nil]])
MetaData = InheritMeta([[ebps\environment\urban\defensive_wall\defensive_wall.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/defensive_wall/defensive_wall_01_45"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
