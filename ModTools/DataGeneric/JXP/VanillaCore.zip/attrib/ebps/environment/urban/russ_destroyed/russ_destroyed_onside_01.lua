----------------------------------------
-- File: 'ebps\environment\urban\russ_destroyed\russ_destroyed_onside_01.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\russ_destroyed\russ_destroyed.nil]])
MetaData = InheritMeta([[ebps\environment\urban\russ_destroyed\russ_destroyed.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/russ_destroyed/russ_destroyed_onside_01"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
