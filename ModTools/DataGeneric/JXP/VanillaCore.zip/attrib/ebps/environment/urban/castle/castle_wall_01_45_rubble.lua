----------------------------------------
-- File: 'ebps\environment\urban\castle\castle_wall_01_45_rubble.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[ebps\environment\urban\castle\castle.nil]])
MetaData = InheritMeta([[ebps\environment\urban\castle\castle.nil]])

GameData["entity_blueprint_ext"]["animator"] = "environment/urban/castle/castle_wall_01_45_rubble"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
