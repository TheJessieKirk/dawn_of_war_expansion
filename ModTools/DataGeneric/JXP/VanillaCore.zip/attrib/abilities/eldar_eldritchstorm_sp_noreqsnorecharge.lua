----------------------------------------
-- File: 'abilities\eldar_eldritchstorm_sp_noreqsnorecharge.lua'
-- Created by: AttributeEditor v2.0
-- Note: Do NOT edit by hand!
-- (c) 2001 Relic Entertainment Inc.

GameData = Inherit([[abilities\eldar_eldritchstorm.lua]])
MetaData = InheritMeta([[abilities\eldar_eldritchstorm.lua]])

GameData["recharge_time"] = 6.00000
GameData["requirements"]["required_1"] = Reference([[requirements\required_none.lua]])
GameData["ui_hotkey_name"] = "marine_orbital_bombardment"


MetaData["$METADATATAG"] = {desc = [[]], type = 7, category = [[]], dispval = [[]], isLocked = false, }
MetaData["$METACOLOURTAG"] = 
{

}
